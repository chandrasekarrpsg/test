<!DOCTYPE html>
<html>
<body width="600px">
<div style="display:block; margin-left:400px; padding:10px;">
<h2>TEST Encrypted Forms</h2>

<form action="monbsk.php" method="post">
  <label for="enctxt">Encrypted String</label><br>
  <input type="text" id="enctxt" name="enctxt" ><br>
  <label for="tckt">Ticket No:</label><br>
  <input type="text" id="tckt" name="tckt" ><br><br>
  <input type="submit" name="submit" value="Submit">
</form> 

</div>
</body>
</html>