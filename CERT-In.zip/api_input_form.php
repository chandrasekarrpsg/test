<!DOCTYPE html>
<html>
<head>
  <title>Return Response JSON2</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
 
</head>
<body width="600px" style="background-color:ivory">
<div style="display:block; margin-left:400px; padding:10px;">
<h2>API response</h2>

<form action="bsk_api_response.php" method="post">
  <label for="ApplNo">Enter Application no</label><br>
  <input type="text" id="ApplNo" name="ApplNo" ><br>
  
  <input type="submit" name="submit" value="Submit">
</form> 

</div>
</body>
</html>