cp $1 $HOME/GENORBL/genorbl/web/.
cp $1 $HOME/GENORBL/genorbl/build/web/.

